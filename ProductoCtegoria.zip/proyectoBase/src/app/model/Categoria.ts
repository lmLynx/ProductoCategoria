export class Categoria{
    idCategoria: number=0;
    nombreCategoria: string='';
    descripcionCategoria: string='';
}